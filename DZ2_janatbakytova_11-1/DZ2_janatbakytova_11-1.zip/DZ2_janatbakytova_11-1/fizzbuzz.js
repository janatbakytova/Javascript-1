// for (let one = 1; one < 101; one++) {
//     if (one % 15 == 0) console.log("FizzBuzz");
//     else if (one % 3 == 0) console.log("Fizz");
//     else if (one % 5 == 0) console.log("Buzz");
//     else console.log(one);
// }
for (let one = 1; one < 101; one++) {
    if (one % 15 == 0) console.log("ХОЧУ С ВАМИ В КИНО");
    else if (one % 3 == 0) console.log("ХОЧУ С ВАМИ");
    else if (one % 5 == 0) console.log("В КИНО");
    else console.log(one);
}